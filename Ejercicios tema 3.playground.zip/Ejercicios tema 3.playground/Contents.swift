import UIKit

//Primera parte

func suma (param1:Int, param2:Int, param3:Int) {
    let resultado = param1 + param2 + param3
    print(resultado)
}

suma(param1:4, param2: 4, param3: 7)


//Segunda parte

class Coche {
    var puertas = 5
    
    func añadirPuerta () {
        puertas += 1
    }
}

var miCoche = Coche()

miCoche.añadirPuerta()

print(miCoche.puertas)


