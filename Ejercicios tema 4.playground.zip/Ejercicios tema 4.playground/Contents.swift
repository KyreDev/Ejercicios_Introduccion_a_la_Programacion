import UIKit

//IF

var numeroIf = -4

if numeroIf == 0 {
    print("El número \(numeroIf) es cero")
} else if numeroIf < 0 {
    print("El número \(numeroIf) es negativo")
} else {
    print("El número \(numeroIf) es positivo")
}


//WHILE

var numeroWhile = 0

while numeroWhile < 3 {
    numeroWhile += 1
    print(numeroWhile)
}


//DO WHILE (REPEAT WHILE EN SWIFT)

var numeroDoWhile = 0

repeat {
    numeroDoWhile += 3
    print(numeroDoWhile)
} while numeroDoWhile < 3

//FOR -- Como no entiendo el enunciado, hago un Fizz Buzz que aprendí hace poco a hacerlo :D

var FizzBuzz = 1...100

for i in FizzBuzz {
    
    let Fizz = i % 3 == 0
    let Buzz = i % 5 == 0
    let FizzBuzz = i % 15 == 0
    
    if FizzBuzz {
        print("FizzBuzz")
    } else if Fizz {
        print("Fizz")
    } else if Buzz {
        print("Buzz")
    } else {
        print(i)
    }
}

//SWITCH

var estacion = ""

switch estacion {
case "Invierno" :
    print("Es Invierno")
case "Primavera" :
    print("Es Primavera")
case "Verano" :
    print("Es Verano")
case "Otoño" :
    print("Es Otoño")
default :
    print("Ingresa una estación")
}



